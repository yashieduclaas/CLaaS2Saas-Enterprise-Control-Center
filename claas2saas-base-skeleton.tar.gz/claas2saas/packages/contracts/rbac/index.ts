/**
 * RBAC contracts — placeholder.
 * Define role, permission, and assignment shapes here.
 */

export interface PermissionKey {
  readonly domain: string;
  readonly action: string;
}

export type PermissionString = `${string}:${string}`;
