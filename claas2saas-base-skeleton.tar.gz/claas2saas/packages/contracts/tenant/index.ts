/**
 * Tenant contracts — placeholder.
 */

export interface TenantSummary {
  readonly tenantId: string;
  readonly displayName: string;
}
