/**
 * API envelope contracts.
 */

export interface ApiResponse<T> {
  readonly success: boolean;
  readonly data: T | null;
  readonly errorCode: string | null;
  readonly errorMessage: string | null;
}
