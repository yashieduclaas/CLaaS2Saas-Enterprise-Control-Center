import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { FluentProvider, webLightTheme } from '@fluentui/react-components';
import { AuthProvider } from './auth/AuthProvider';
import { PermissionProvider } from './permissions/PermissionProvider';
import { AppLayout } from './layout/AppLayout';
import { HomePage } from './pages/HomePage';
import { TenantsPage } from './pages/TenantsPage';

export function App(): JSX.Element {
  return (
    <FluentProvider theme={webLightTheme}>
      <AuthProvider>
        <PermissionProvider>
          <BrowserRouter>
            <AppLayout>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/tenants" element={<TenantsPage />} />
              </Routes>
            </AppLayout>
          </BrowserRouter>
        </PermissionProvider>
      </AuthProvider>
    </FluentProvider>
  );
}
