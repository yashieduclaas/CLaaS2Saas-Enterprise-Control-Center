import { type ReactNode } from 'react';
import {
  MsalProvider,
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
} from '@azure/msal-react';
import {
  PublicClientApplication,
  InteractionStatus,
  type AccountInfo,
} from '@azure/msal-browser';
import { msalConfig, defaultScopes } from './msalConfig';

/**
 * PLATFORM AUTH PROVIDER — FROZEN.
 * All MSAL usage is encapsulated here. Feature pods must not create MSAL instances.
 */

export const msalInstance = new PublicClientApplication(msalConfig);

const initialAccounts = msalInstance.getAllAccounts();
if (initialAccounts.length > 0 && initialAccounts[0]) {
  msalInstance.setActiveAccount(initialAccounts[0]);
}

export interface AuthContext {
  readonly account: AccountInfo | null;
  readonly isLoading: boolean;
  acquireToken: () => Promise<string>;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
}

function useAuthInternal(): AuthContext {
  const { instance, accounts, inProgress } = useMsal();
  const account = accounts[0] ?? null;
  const isLoading = inProgress !== InteractionStatus.None;

  const acquireToken = async (): Promise<string> => {
    if (!account) throw new Error('No authenticated account.');
    try {
      const result = await instance.acquireTokenSilent({ account, scopes: defaultScopes });
      return result.accessToken;
    } catch {
      await instance.acquireTokenRedirect({ account, scopes: defaultScopes });
      throw new Error('Redirect initiated.');
    }
  };

  const signIn = async () => instance.loginRedirect({ scopes: defaultScopes });
  const signOut = async () => instance.logoutRedirect({ account: account ?? undefined });

  return { account, isLoading, acquireToken, signIn, signOut };
}

export const useAuth = useAuthInternal;

interface AuthProviderProps {
  readonly children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps): JSX.Element {
  return (
    <MsalProvider instance={msalInstance}>
      <AuthenticatedTemplate>{children}</AuthenticatedTemplate>
      <UnauthenticatedTemplate><UnauthenticatedView /></UnauthenticatedTemplate>
    </MsalProvider>
  );
}

function UnauthenticatedView(): JSX.Element {
  const { signIn, isLoading } = useAuthInternal();
  return (
    <div style={{ display:'flex', height:'100vh', alignItems:'center', justifyContent:'center' }}>
      <button onClick={() => void signIn()} disabled={isLoading} style={{ padding:'12px 24px', fontSize:16 }}>
        {isLoading ? 'Signing in…' : 'Sign in with Microsoft'}
      </button>
    </div>
  );
}
