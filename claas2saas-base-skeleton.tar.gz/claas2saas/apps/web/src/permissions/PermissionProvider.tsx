import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuth } from '../auth/AuthProvider';

export interface PermissionSnapshot {
  readonly permissions: ReadonlySet<string>;
  readonly isLoading: boolean;
  readonly error: Error | null;
}

const PermissionContext = createContext<PermissionSnapshot | null>(null);

interface Props { readonly children: ReactNode; }

export function PermissionProvider({ children }: Props): JSX.Element {
  const { acquireToken, account } = useAuth();
  const [snapshot, setSnapshot] = useState<PermissionSnapshot>({
    permissions: new Set(), isLoading: true, error: null,
  });

  useEffect(() => {
    if (!account) return;
    let cancelled = false;
    const load = async () => {
      try {
        const token = await acquireToken();
        const res = await fetch('/api/v1/permissions/snapshot', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { permissions: string[] };
        if (!cancelled) setSnapshot({ permissions: new Set(data.permissions), isLoading: false, error: null });
      } catch (err) {
        if (!cancelled) {
          const error = err instanceof Error ? err : new Error(String(err));
          console.error('[PermissionProvider]', error);
          setSnapshot({ permissions: new Set(), isLoading: false, error });
        }
      }
    };
    void load();
    return () => { cancelled = true; };
  }, [account, acquireToken]);

  return <PermissionContext.Provider value={snapshot}>{children}</PermissionContext.Provider>;
}

export function usePermissionContext(): PermissionSnapshot {
  const ctx = useContext(PermissionContext);
  if (!ctx) throw new Error('usePermissionContext must be inside <PermissionProvider>.');
  return ctx;
}

export function usePermission(permission: string): boolean | undefined {
  const { permissions, isLoading } = usePermissionContext();
  if (isLoading) return undefined;
  return permissions.has(permission);
}
