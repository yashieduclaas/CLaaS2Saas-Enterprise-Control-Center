import { useState, type ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { makeStyles, tokens } from '@fluentui/react-components';
import { ROUTE_MAP, type RouteKey } from '../routes/routeMap';

/**
 * PLATFORM APP LAYOUT — FROZEN.
 *
 * Entra-style shell with collapsible left NavRail.
 * Feature pods render inside the <main> region only.
 *
 * Navigation is platform-owned. Feature pods add routes via ROUTE_MAP.
 */

const useStyles = makeStyles({
  shell: {
    display: 'flex',
    height: '100vh',
    overflow: 'hidden',
    backgroundColor: tokens.colorNeutralBackground2,
  },
  rail: {
    display: 'flex',
    flexDirection: 'column',
    width: '220px',
    minWidth: '220px',
    backgroundColor: tokens.colorNeutralBackground1,
    borderRight: `1px solid ${tokens.colorNeutralStroke2}`,
    transition: 'width 200ms ease, min-width 200ms ease',
    overflow: 'hidden',
  },
  railCollapsed: {
    width: '48px',
    minWidth: '48px',
  },
  railHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalM}`,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    minHeight: '48px',
  },
  wordmark: {
    fontSize: tokens.fontSizeBase300,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
  },
  toggleBtn: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: tokens.colorNeutralForeground2,
    borderRadius: tokens.borderRadiusMedium,
    ':hover': {
      backgroundColor: tokens.colorNeutralBackground1Hover,
    },
  },
  navList: {
    listStyle: 'none',
    margin: 0,
    padding: `${tokens.spacingVerticalS} 0`,
    flex: 1,
    overflowY: 'auto',
  },
  navItem: {
    display: 'block',
    padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalM}`,
    color: tokens.colorNeutralForeground2,
    textDecoration: 'none',
    borderRadius: tokens.borderRadiusMedium,
    margin: `2px ${tokens.spacingHorizontalXS}`,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    fontSize: tokens.fontSizeBase300,
    ':hover': {
      backgroundColor: tokens.colorNeutralBackground1Hover,
      color: tokens.colorNeutralForeground1,
    },
  },
  navItemActive: {
    backgroundColor: tokens.colorBrandBackground2,
    color: tokens.colorBrandForeground1,
    fontWeight: tokens.fontWeightSemibold,
  },
  main: {
    flex: 1,
    overflow: 'auto',
    padding: tokens.spacingHorizontalXL,
  },
});

interface AppLayoutProps {
  readonly children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps): JSX.Element {
  const styles = useStyles();
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const navEntries = Object.entries(ROUTE_MAP) as [RouteKey, (typeof ROUTE_MAP)[RouteKey]][];

  return (
    <div className={styles.shell}>
      {/* ── NavRail ─────────────────────────────────────────────────── */}
      <nav
        className={`${styles.rail}${collapsed ? ` ${styles.railCollapsed}` : ''}`}
        aria-label="Main navigation"
      >
        <div className={styles.railHeader}>
          {!collapsed && <span className={styles.wordmark}>CLaaS2SaaS</span>}
          <button
            className={styles.toggleBtn}
            onClick={() => setCollapsed(c => !c)}
            aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
            title={collapsed ? 'Expand navigation' : 'Collapse navigation'}
          >
            {collapsed ? '›' : '‹'}
          </button>
        </div>

        <ul className={styles.navList} role="list">
          {navEntries.map(([key, entry]) => {
            const isActive = location.pathname === entry.path;
            return (
              <li key={key}>
                <NavLink
                  to={entry.path}
                  className={`${styles.navItem}${isActive ? ` ${styles.navItemActive}` : ''}`}
                  title={entry.label}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {collapsed ? entry.label.charAt(0) : entry.label}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* ── Content ─────────────────────────────────────────────────── */}
      <main className={styles.main} id="main-content" tabIndex={-1}>
        {children}
      </main>
    </div>
  );
}
