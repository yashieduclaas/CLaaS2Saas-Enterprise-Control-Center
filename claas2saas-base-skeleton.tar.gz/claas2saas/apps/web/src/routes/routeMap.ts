/**
 * PLATFORM ROUTE MAP — FROZEN STRUCTURE, ADDITIVE CONTENT.
 *
 * This is the authoritative registry of all application routes.
 * Feature pods add entries; they never remove or rename existing ones.
 *
 * Permission values must align with the contracts package.
 */

export const ROUTE_MAP = {
  HOME: {
    path: '/',
    label: 'Home',
    requiredPermission: null,
  },
  TENANTS: {
    path: '/tenants',
    label: 'Tenants',
    requiredPermission: 'TENANT:READ',
  },
  // ── Feature pods append entries below this line ──────────────────────────
} as const;

export type RouteKey = keyof typeof ROUTE_MAP;
export type RouteEntry = (typeof ROUTE_MAP)[RouteKey];
