import { makeStyles, tokens, Title1, Text } from '@fluentui/react-components';
import { ExampleCard } from '../components/ExampleCard';
import { useAuth } from '../auth/AuthProvider';

const useStyles = makeStyles({
  root: { display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalL },
  cards: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: tokens.spacingHorizontalM },
});

export function HomePage(): JSX.Element {
  const styles = useStyles();
  const { account } = useAuth();

  return (
    <div className={styles.root}>
      <Title1>CLaaS2SaaS Security Kernel</Title1>
      <Text>Platform foundation loaded. Feature pods attach here.</Text>
      <div className={styles.cards}>
        <ExampleCard label="Authenticated as" value={account?.username ?? '—'} />
        <ExampleCard label="Platform" value="Entra ID + RBAC" />
        <ExampleCard label="Status" value="Operational" />
      </div>
    </div>
  );
}
