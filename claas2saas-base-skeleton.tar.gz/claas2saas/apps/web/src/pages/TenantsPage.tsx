import { Title1, Text } from '@fluentui/react-components';
import { usePermission } from '../permissions/PermissionProvider';

export function TenantsPage(): JSX.Element {
  const canRead = usePermission('TENANT:READ');

  if (canRead === undefined) return <Text>Loading permissions…</Text>;
  if (!canRead) return <Text>Access denied.</Text>;

  return (
    <>
      <Title1>Tenants</Title1>
      <Text>Tenant management feature pod will render here.</Text>
    </>
  );
}
