using Kernel.Application.Authorization;
using Kernel.Infrastructure.DependencyInjection;
using Kernel.Infrastructure.Middleware;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

// ── Logging ──────────────────────────────────────────────────────────────────
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddJsonConsole(o => o.JsonWriterOptions = new() { Indented = false });

// ── Authentication (Entra JWT Bearer) ────────────────────────────────────────
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        // TODO: Replace with your Entra tenant authority
        // e.g. https://login.microsoftonline.com/{tenantId}/v2.0
        options.Authority = builder.Configuration["Entra:Authority"]
            ?? throw new InvalidOperationException("Entra:Authority must be configured.");

        // TODO: Replace with your registered application (client) ID
        options.Audience = builder.Configuration["Entra:Audience"]
            ?? throw new InvalidOperationException("Entra:Audience must be configured.");

        options.TokenValidationParameters.ClockSkew = TimeSpan.FromMinutes(2);
        options.TokenValidationParameters.ValidateIssuerSigningKey = true;
    });

// ── Authorization policies ───────────────────────────────────────────────────
builder.Services.AddAuthorization(options =>
{
    // All named policies route through IPermissionEvaluator.
    // No role-based shortcuts are permitted.
    void AddPermissionPolicy(string policy, string permission) =>
        options.AddPolicy(policy, p => p.Requirements.Add(new PermissionRequirement(permission)));

    AddPermissionPolicy(Policies.AdminGlobal, Permissions.AdminGlobal);
    AddPermissionPolicy(Policies.UsersRead,   Permissions.UsersRead);
    AddPermissionPolicy(Policies.UsersWrite,  Permissions.UsersWrite);
    AddPermissionPolicy(Policies.TenantRead,  Permissions.TenantRead);

    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

// ── Infrastructure (TenantContext, IPermissionEvaluator, handler) ────────────
builder.Services.AddKernelInfrastructure();

// ── Problem Details ───────────────────────────────────────────────────────────
builder.Services.AddProblemDetails();

// ── Controllers ───────────────────────────────────────────────────────────────
builder.Services.AddControllers();

// ── Health ────────────────────────────────────────────────────────────────────
builder.Services.AddHealthChecks();

var app = builder.Build();

// ══════════════════════════════════════════════════════════════════════════════
// MIDDLEWARE ORDER — FROZEN. Do not reorder without architecture approval.
// ══════════════════════════════════════════════════════════════════════════════
app.UseExceptionHandler();
app.UseStatusCodePages();
app.UseHttpsRedirection();

app.UseAuthentication();            // 1️⃣  Identify the caller
app.UseMiddleware<TenantMiddleware>(); // 2️⃣  Resolve tenant from identity
app.UseAuthorization();             // 3️⃣  Enforce policies

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
