using Kernel.Application.Abstractions;
using Kernel.Infrastructure.Authorization;
using Kernel.Infrastructure.Middleware;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Kernel.Infrastructure.DependencyInjection;

public static class InfrastructureServiceExtensions
{
    /// <summary>
    /// Registers all infrastructure services. Called from Program.cs.
    /// </summary>
    public static IServiceCollection AddKernelInfrastructure(
        this IServiceCollection services,
        Action<TenantMiddlewareOptions>? configureTenant = null)
    {
        // Tenant middleware
        services.Configure<TenantMiddlewareOptions>(opt =>
        {
            opt.RequireResolved = true;
            configureTenant?.Invoke(opt);
        });
        services.AddScoped<ITenantContext, TenantContext>();

        // Permission evaluator — STUB until real engine is wired
        services.AddScoped<IPermissionEvaluator, StubPermissionEvaluator>();

        // Authorization handler
        services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();

        return services;
    }
}
