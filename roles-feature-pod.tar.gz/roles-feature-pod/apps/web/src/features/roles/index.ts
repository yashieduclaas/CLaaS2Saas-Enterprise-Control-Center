// apps/web/src/features/roles/index.ts
// Public API of the roles feature slice.
// Only re-export what AppRouter needs.

export { default as RolesPage } from "./components/RolesPage";
