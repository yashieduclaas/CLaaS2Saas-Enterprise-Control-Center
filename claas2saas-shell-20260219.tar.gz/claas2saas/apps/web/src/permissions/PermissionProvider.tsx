import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuthContext } from '../auth/AuthContext';
import { getDemoUserEmail } from '../auth/DemoAuthProvider';

const isDemo = import.meta.env.VITE_AUTH_MODE === 'demo';
const API_BASE = import.meta.env.VITE_API_URL ?? '';

function getAuthHeaders(token: string): Record<string, string> {
  if (isDemo) {
    return { 'X-Demo-User': getDemoUserEmail() };
  }
  return { Authorization: `Bearer ${token}` };
}

export interface PermissionSnapshot {
  readonly permissions: ReadonlySet<string>;
  readonly isLoading: boolean;
  readonly error: Error | null;
  readonly refresh: () => void;
}

const PermissionContext = createContext<PermissionSnapshot | null>(null);

interface Props { readonly children: ReactNode; }

export function PermissionProvider({ children }: Props): JSX.Element {
  const { acquireToken, account } = useAuthContext();
  const [snapshot, setSnapshot] = useState<Omit<PermissionSnapshot, 'refresh'>>({
    permissions: new Set(), isLoading: true, error: null,
  });
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    if (!account) return;
    let cancelled = false;
    const load = async () => {
      try {
        const token = await acquireToken();
        const res = await fetch(`${API_BASE}/api/v1/permissions/snapshot`, {
          headers: { ...getAuthHeaders(token), 'Content-Type': 'application/json' },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { permissions?: string[]; Permissions?: string[] };
        const perms = data.permissions ?? data.Permissions ?? [];
        if (!cancelled) setSnapshot({ permissions: new Set(perms), isLoading: false, error: null });
      } catch (err) {
        if (!cancelled) {
          const error = err instanceof Error ? err : new Error(String(err));
          console.error('[PermissionProvider]', error);
          setSnapshot({ permissions: new Set(), isLoading: false, error });
        }
      }
    };
    void load();
    return () => { cancelled = true; };
  }, [account, acquireToken, refreshTrigger]);

  useEffect(() => {
    if (!isDemo) return;
    const onChanged = () => setRefreshTrigger((t) => t + 1);
    window.addEventListener('demo-user-changed', onChanged);
    return () => window.removeEventListener('demo-user-changed', onChanged);
  }, []);

  const refresh = () => setRefreshTrigger((t) => t + 1);

  return (
    <PermissionContext.Provider value={{ ...snapshot, refresh }}>
      {children}
    </PermissionContext.Provider>
  );
}

export function usePermissionContext(): PermissionSnapshot {
  const ctx = useContext(PermissionContext);
  if (!ctx) throw new Error('usePermissionContext must be inside <PermissionProvider>.');
  return ctx;
}

export function usePermission(permission: string): boolean | undefined {
  const { permissions, isLoading } = usePermissionContext();
  if (isLoading) return undefined;
  return permissions.has(permission);
}
