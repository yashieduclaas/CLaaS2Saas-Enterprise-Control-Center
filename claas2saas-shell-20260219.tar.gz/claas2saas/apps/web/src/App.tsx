import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { FluentProvider, webLightTheme } from '@fluentui/react-components';
import { QueryClientProvider } from '@tanstack/react-query';
import { DemoAuthProvider } from './auth/DemoAuthProvider';
import { PermissionProvider } from './rbac/PermissionProvider';
import { PermissionGuard } from './rbac/PermissionGuard';
import { AppLayout } from './app/AppLayout';
import { PageSkeleton } from './app/PageSkeleton';
import { DemoModeBanner } from './dev/DemoModeBanner';
import { HomePage } from './pages/HomePage';
import { TenantsPage } from './pages/TenantsPage';
import { PlaceholderPage } from './pages/PlaceholderPage';
import { queryClient } from './api/queryClient';

const isDemo = import.meta.env.VITE_AUTH_MODE === 'demo';

const EntraAuthShell = lazy(() =>
  import('./auth/EntraAuthShell').then((m) => ({ default: m.EntraAuthShell }))
);
const RoleManagementPage = lazy(() =>
  import('./features/roles/pages/RoleManagementPage').then((m) => ({ default: m.default }))
);
const AuditActionsPage = lazy(() =>
  import('./features/audit/pages/AuditActionsPage').then((m) => ({ default: m.AuditActionsPage }))
);

function AuthAndPermissionGate({ children }: { children: React.ReactNode }): JSX.Element {
  return <PermissionProvider>{children}</PermissionProvider>;
}

export function App(): JSX.Element {
  const content = (
    <BrowserRouter>
      {isDemo && <DemoModeBanner />}
      <div style={{ paddingTop: isDemo ? 48 : 0 }}>
        <AppLayout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tenants" element={<TenantsPage />} />
            <Route path="/dashboard" element={<PlaceholderPage title="Dashboard" />} />
            <Route path="/modules" element={<PlaceholderPage title="Module management" />} />
            <Route path="/user-profile" element={<PlaceholderPage title="User profile enrichment" />} />
            <Route
              path="/roles"
              element={
                <PermissionGuard routeKey="roles">
                  <Suspense fallback={<PageSkeleton />}>
                    <RoleManagementPage />
                  </Suspense>
                </PermissionGuard>
              }
            />
            <Route path="/security/roles" element={<PlaceholderPage title="Security role management" />} />
            <Route path="/security/user-assignments" element={<PlaceholderPage title="User role assignment" />} />
            <Route
              path="/audit/actions"
              element={
                <PermissionGuard routeKey="audit-logs">
                  <Suspense fallback={<PageSkeleton />}>
                    <AuditActionsPage />
                  </Suspense>
                </PermissionGuard>
              }
            />
          </Routes>
        </AppLayout>
      </div>
    </BrowserRouter>
  );

  return (
    <FluentProvider theme={webLightTheme}>
      <QueryClientProvider client={queryClient}>
        {isDemo ? (
          <DemoAuthProvider>
            <AuthAndPermissionGate>{content}</AuthAndPermissionGate>
          </DemoAuthProvider>
        ) : (
          <Suspense fallback={<div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center' }}>Loading…</div>}>
            <EntraAuthShell>
              <AuthAndPermissionGate>{content}</AuthAndPermissionGate>
            </EntraAuthShell>
          </Suspense>
        )}
      </QueryClientProvider>
    </FluentProvider>
  );
}
