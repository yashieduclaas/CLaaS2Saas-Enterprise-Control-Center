/**
 * RBAC feature exports.
 */

export { PermissionProvider, usePermissionContext } from './PermissionProvider';
export { usePermission } from './usePermission';
export { PermissionGuard } from './PermissionGuard';
export type { PermissionCode, PermissionContextValue } from './types';
