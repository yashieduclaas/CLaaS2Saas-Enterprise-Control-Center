/**
 * Permission abstraction — swap-ready for real RBAC.
 * Supplies permissions via API or demo map. NO role checks.
 */

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuthContext } from '@/auth/AuthContext';
import { getDemoUserEmail } from '@/auth/DemoAuthProvider';
import { getDemoPermissions, isDemoDataMode } from '@/demo';
import type { PermissionContextValue } from './types';

const isDemoAuth = import.meta.env.VITE_AUTH_MODE === 'demo';
const API_BASE = import.meta.env.VITE_API_URL ?? '';

function getAuthHeaders(token: string): Record<string, string> {
  if (isDemoAuth) {
    return { 'X-Demo-User': getDemoUserEmail() };
  }
  return { Authorization: `Bearer ${token}` };
}

const PermissionContext = createContext<PermissionContextValue | null>(null);

interface Props {
  readonly children: ReactNode;
}

export function PermissionProvider({ children }: Props): JSX.Element {
  const { acquireToken, account } = useAuthContext();
  const [state, setState] = useState<Omit<PermissionContextValue, 'refresh'>>({
    permissions: new Set(),
    isLoading: true,
    error: null,
  });
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    if (!account) {
      setState({ permissions: new Set(), isLoading: false, error: null });
      return;
    }

    const useDemoMap = isDemoAuth && isDemoDataMode();

    if (useDemoMap) {
      const email = account.username ?? getDemoUserEmail();
      const perms = getDemoPermissions(email);
      const simulated = () =>
        setTimeout(() => {
          setState({
            permissions: new Set(perms),
            isLoading: false,
            error: null,
          });
        }, 300);
      const t = simulated();
      return () => clearTimeout(t);
    }

    let cancelled = false;
    const load = async () => {
      try {
        const token = await acquireToken();
        const res = await fetch(`${API_BASE}/api/v1/permissions/snapshot`, {
          headers: { ...getAuthHeaders(token), 'Content-Type': 'application/json' },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { permissions?: string[]; Permissions?: string[] };
        const perms = data.permissions ?? data.Permissions ?? [];
        if (!cancelled) {
          setState({ permissions: new Set(perms), isLoading: false, error: null });
        }
      } catch (err) {
        if (!cancelled) {
          const error = err instanceof Error ? err : new Error(String(err));
          setState({ permissions: new Set(), isLoading: false, error });
        }
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [account, acquireToken, refreshTrigger]);

  useEffect(() => {
    if (!isDemoAuth) return;
    const onChanged = () => setRefreshTrigger((t) => t + 1);
    window.addEventListener('demo-user-changed', onChanged);
    return () => window.removeEventListener('demo-user-changed', onChanged);
  }, []);

  const refresh = () => setRefreshTrigger((t) => t + 1);

  return (
    <PermissionContext.Provider value={{ ...state, refresh }}>
      {children}
    </PermissionContext.Provider>
  );
}

export function usePermissionContext(): PermissionContextValue {
  const ctx = useContext(PermissionContext);
  if (!ctx) throw new Error('usePermissionContext must be inside <PermissionProvider>.');
  return ctx;
}
