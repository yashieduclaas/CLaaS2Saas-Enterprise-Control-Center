/**
 * usePermission(code) — returns boolean when not loading.
 * usePermissionContext() — full context. NO role checks.
 */

import type { PermissionCode } from './types';
import { usePermissionContext } from './PermissionProvider';

export function usePermission(code: PermissionCode | null): boolean {
  const { permissions, isLoading } = usePermissionContext();
  if (isLoading) return false;
  if (code === null) return true;
  return permissions.has(code);
}
