/**
 * PermissionGuard — gate for route-level RBAC.
 * Uses ROUTE_MAP to resolve required permission from pageKey.
 * NO role checks.
 */

import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { makeStyles, Skeleton, SkeletonItem, tokens } from '@fluentui/react-components';
import { usePermissionContext } from '@/rbac/PermissionProvider';
import { usePermission } from '@/rbac/usePermission';
import { ROUTE_MAP } from '@/routes/RoutePermissionMap';
import type { RouteKey } from '@/routes/RoutePermissionMap';

const useSkeletonStyles = makeStyles({
  item: {
    marginTop: tokens.spacingVerticalS,
    width: '40%',
  },
  itemLarge: {
    marginTop: tokens.spacingVerticalL,
  },
});

interface PermissionGuardProps {
  readonly routeKey: RouteKey;
  readonly children: ReactNode;
}

function PermissionLoadingSkeleton(): JSX.Element {
  const styles = useSkeletonStyles();
  return (
    <Skeleton aria-label="Loading permissions…">
      <SkeletonItem size={32} />
      <SkeletonItem size={16} className={styles.item} />
      <SkeletonItem size={48} className={styles.itemLarge} />
    </Skeleton>
  );
}

export function PermissionGuard({ routeKey, children }: PermissionGuardProps): JSX.Element {
  const { isLoading } = usePermissionContext();
  const entry = ROUTE_MAP.find((e) => e.pageKey === routeKey);
  const requiredPermission = entry?.requiredPermission ?? null;

  if (requiredPermission === null) {
    return <>{children}</>;
  }

  if (isLoading) return <PermissionLoadingSkeleton />;

  const hasPermission = usePermission(requiredPermission);

  if (!hasPermission) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
