/**
 * RBAC types — permission abstraction layer.
 * PermissionCode from contracts; NO role checks in this layer.
 * Swap-ready for real RBAC backend.
 */

import type { PermissionCodeType } from '@claas2saas/contracts';

/** Re-export for feature consumption. */
export type PermissionCode = PermissionCodeType;

/** Context value exposed by PermissionProvider. */
export interface PermissionContextValue {
  readonly permissions: ReadonlySet<string>;
  readonly isLoading: boolean;
  readonly error: Error | null;
  readonly refresh: () => void;
}
