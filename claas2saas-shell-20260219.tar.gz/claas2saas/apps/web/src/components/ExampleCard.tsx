import { makeStyles, tokens, Text } from '@fluentui/react-components';

/**
 * Example component — demonstrates Griffel + Fluent token usage.
 * All styles use makeStyles() and tokens. No inline styles, no hardcoded colors.
 */

const useStyles = makeStyles({
  root: {
    backgroundColor: tokens.colorNeutralBackground1,
    borderRadius: tokens.borderRadiusMedium,
    border: `1px solid ${tokens.colorNeutralStroke2}`,
    padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalL}`,
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalS,
  },
  label: {
    color: tokens.colorNeutralForeground3,
    fontSize: tokens.fontSizeBase100,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
  },
  value: {
    color: tokens.colorNeutralForeground1,
    fontSize: tokens.fontSizeBase400,
    fontWeight: tokens.fontWeightSemibold,
  },
});

interface ExampleCardProps {
  readonly label: string;
  readonly value: string;
}

export function ExampleCard({ label, value }: ExampleCardProps): JSX.Element {
  const styles = useStyles();
  return (
    <div className={styles.root}>
      <Text className={styles.label}>{label}</Text>
      <Text className={styles.value}>{value}</Text>
    </div>
  );
}
