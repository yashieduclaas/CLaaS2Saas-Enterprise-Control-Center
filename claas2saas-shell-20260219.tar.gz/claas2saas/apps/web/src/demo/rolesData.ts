/**
 * Demo roles data — static roles for LOCAL mode.
 * Simulates GET /api/v1/roles. Remove when wiring real API.
 */

import type { RoleDto } from '@claas2saas/contracts';

export const DEMO_ROLES: readonly RoleDto[] = [
  {
    id: 'role-1',
    name: 'GLOBAL_ADMIN',
    description: 'Full tenant administration. Break-glass access.',
    isSystemRole: true,
    updatedAt: '2026-02-15T10:30:00.000Z',
  },
  {
    id: 'role-2',
    name: 'SECURITY_ADMIN',
    description: 'Day-to-day security administration. Manages roles and assignments.',
    isSystemRole: true,
    updatedAt: '2026-02-16T14:00:00.000Z',
  },
  {
    id: 'role-3',
    name: 'HELP_DESK',
    description: 'Read-only support. Views assignments and access status.',
    isSystemRole: true,
    updatedAt: '2026-02-14T09:15:00.000Z',
  },
  {
    id: 'role-4',
    name: 'STANDARD_USER',
    description: 'Self-service. Views own assignments and submits access requests.',
    isSystemRole: true,
    updatedAt: '2026-02-17T11:45:00.000Z',
  },
  {
    id: 'role-5',
    name: 'Custom Auditor',
    description: 'Custom role for audit compliance review.',
    isSystemRole: false,
    updatedAt: '2026-02-18T16:20:00.000Z',
  },
];

/** Simulated API delay (ms). */
export const DEMO_LOAD_DELAY_MS = 600;
