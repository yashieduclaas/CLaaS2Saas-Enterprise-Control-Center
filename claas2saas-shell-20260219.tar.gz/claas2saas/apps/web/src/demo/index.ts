/**
 * Demo mode adapter — swap point for real backend.
 * When VITE_DATA_MODE=Local, use static data + simulated delay.
 */

export { getDemoPermissions, DEMO_PERMISSION_MAP } from './permissionMap';
export { DEMO_ROLES, DEMO_LOAD_DELAY_MS } from './rolesData';

export const isDemoDataMode = (): boolean =>
  import.meta.env.VITE_DATA_MODE === 'Local';
