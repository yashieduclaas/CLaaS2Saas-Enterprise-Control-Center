/**
 * Demo permission map — static permissions per demo user.
 * Used when VITE_DATA_MODE=Local. NO role checks — permission-only.
 * Remove this file when wiring real RBAC; swap via PermissionProvider adapter.
 */

import { PermissionCode } from '@claas2saas/contracts';

const ALL_PERMISSIONS = Object.values(PermissionCode) as string[];

/** Demo user email → permission codes. */
export const DEMO_PERMISSION_MAP: Record<string, readonly string[]> = {
  'global.admin@demo.com': ALL_PERMISSIONS,
  'security.admin@demo.com': [
    PermissionCode.ROLE_READ,
    PermissionCode.ROLE_MANAGE,
    PermissionCode.AUDIT_VIEW_ACTIONS,
  ],
  'helpdesk@demo.com': [PermissionCode.ROLE_READ, PermissionCode.AUDIT_VIEW_ACTIONS],
  'user@tenantA.com': [PermissionCode.USER_PROFILE_READ],
  'user@tenantB.com': [PermissionCode.USER_PROFILE_READ],
};

export function getDemoPermissions(email: string): readonly string[] {
  return DEMO_PERMISSION_MAP[email] ?? [];
}
