/**
 * Singleton React Query client.
 */

import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000, // 30 s
      retry: 1, // One retry — avoid storms
      refetchOnWindowFocus: false,
    },
  },
});
