/**
 * Shared authenticated HTTP client.
 * Uses getAccessToken from useAuth — never imports MSAL directly.
 *
 * Centralized envelope unwrap: ALL success responses go through validateAndUnwrap.
 * Never assume response.data without validation.
 */

import type { ApiEnvelope } from '@claas2saas/contracts';

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly detail: string,
    public readonly correlationId?: string,
  ) {
    super(`API ${status}: ${detail}`);
    this.name = 'ApiError';
  }
}

/** ASP.NET Core ProblemDetails shape for error responses. */
interface ProblemDetails {
  readonly type?: string;
  readonly title?: string;
  readonly status?: number;
  readonly detail?: string;
  readonly instance?: string;
  readonly correlationId?: string;
  readonly traceId?: string;
}

function parseErrorBody(text: string): { detail: string; correlationId?: string } {
  try {
    const json = JSON.parse(text) as ProblemDetails & Record<string, unknown>;
    return {
      detail: json.detail ?? json.title ?? text,
      correlationId: json.correlationId ?? json.traceId,
    };
  } catch {
    return { detail: text, correlationId: undefined };
  }
}

/**
 * Validates and unwraps ApiEnvelope. Throws if envelope or data is invalid.
 * Caller must NEVER assume response.data without going through this.
 */
function validateAndUnwrap<T>(envelope: unknown, path: string): T {
  if (envelope === null || typeof envelope !== 'object') {
    throw new ApiError(502, `Invalid envelope from ${path}: expected object`);
  }
  const bag = envelope as Record<string, unknown>;
  if (!('data' in bag)) {
    throw new ApiError(502, `Invalid envelope from ${path}: missing data property`);
  }
  return bag.data as T;
}

const isDemo = import.meta.env.VITE_AUTH_MODE === 'demo';
const API_BASE = import.meta.env.VITE_API_URL ?? '';

function getAuthHeaders(token: string): Record<string, string> {
  if (isDemo) {
    const demoUser =
      (typeof window !== 'undefined' && localStorage.getItem('demo-user')) ||
      'global.admin@demo.com';
    return { 'X-Demo-User': demoUser };
  }
  return { Authorization: `Bearer ${token}` };
}

/**
 * Typed fetch wrapper. Centralizes:
 * - Non-200 → ApiError (ProblemDetails mapped)
 * - Success → validateAndUnwrap (never assume envelope.data without validation)
 * - Demo mode: adds X-Demo-User header instead of Bearer
 *
 * @param path   - API path e.g. "/api/v1/roles"
 * @param token  - Bearer token from useAuth().getAccessToken() (ignored in demo mode)
 * @param signal - AbortSignal for React Query cancellation
 */
export async function apiFetch<T>(
  path: string,
  token: string,
  signal?: AbortSignal,
): Promise<T> {
  const url = path.startsWith('http') ? path : `${API_BASE}${path}`;
  const init: RequestInit = {
    headers: {
      ...getAuthHeaders(token),
      'Content-Type': 'application/json',
    },
  };
  if (signal !== undefined) {
    init.signal = signal;
  }
  const response = await fetch(url, init);

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    const { detail, correlationId } = parseErrorBody(text);
    throw new ApiError(response.status, detail, correlationId);
  }

  const raw = await response.json().catch(() => null);
  return validateAndUnwrap<T>(raw, path);
}
