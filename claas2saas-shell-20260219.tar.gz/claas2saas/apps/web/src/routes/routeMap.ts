/**
 * PLATFORM ROUTE MAP — Single source of truth.
 * NavRail, routing, PermissionGuard all derive from here.
 */

import { PermissionCode } from '@claas2saas/contracts';

export const ROUTE_MAP = {
  HOME: {
    path: '/',
    label: 'Home',
    requiredPermission: null,
    section: 'main',
  },
  DASHBOARD: {
    path: '/dashboard',
    label: 'Dashboard',
    requiredPermission: PermissionCode.ADMIN_MODULE_SCOPED,
    section: 'main',
  },
  MODULE_MANAGEMENT: {
    path: '/modules',
    label: 'Module management',
    requiredPermission: PermissionCode.MODULE_READ,
    section: 'main',
  },
  USER_PROFILE_ENRICHMENT: {
    path: '/user-profile',
    label: 'User profile enrichment',
    requiredPermission: PermissionCode.USER_PROFILE_READ,
    section: 'main',
  },
  TENANTS: {
    path: '/tenants',
    label: 'Tenants',
    requiredPermission: PermissionCode.TENANT_READ,
    section: 'main',
  },
  // ── Security Control Centre ─────────────────────────────────────────────
  SECURITY_ROLE_MANAGEMENT: {
    path: '/security/roles',
    label: 'Security role management',
    requiredPermission: PermissionCode.ROLE_MANAGE,
    section: 'security',
  },
  USER_ROLE_ASSIGNMENT: {
    path: '/security/user-assignments',
    label: 'User role assignment',
    requiredPermission: PermissionCode.USER_ASSIGN_ROLE,
    section: 'security',
  },
  AUDIT_LOGS: {
    path: '/audit/actions',
    label: 'Audit logs',
    requiredPermission: PermissionCode.AUDIT_VIEW_ACTIONS,
    section: 'security',
  },
  ROLES: {
    path: '/roles',
    label: 'Role Management',
    requiredPermission: PermissionCode.ROLE_READ,
    section: 'security',
  },
} as const;

export type RouteKey = keyof typeof ROUTE_MAP;
export type RouteEntry = (typeof ROUTE_MAP)[RouteKey];
