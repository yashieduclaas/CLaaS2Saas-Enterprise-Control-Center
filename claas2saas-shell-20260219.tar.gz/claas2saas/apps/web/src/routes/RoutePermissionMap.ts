/**
 * ROUTE_MAP — strongly typed, single source of truth.
 * NavRail, routing, PermissionGuard all derive from here.
 * NO hardcoded nav JSX.
 */

import { PermissionCode, type PermissionCodeType } from '@claas2saas/contracts';

export interface RouteMapEntry {
  readonly pageKey: string;
  readonly path: string;
  readonly label: string;
  readonly icon: string;
  readonly requiredPermission: PermissionCodeType | null;
  readonly group: string;
  readonly showInNav: boolean;
}

export const ROUTE_MAP = [
  {
    pageKey: 'home',
    path: '/',
    label: 'Home',
    icon: 'Home',
    requiredPermission: null,
    group: 'main',
    showInNav: true,
  },
  {
    pageKey: 'tenants',
    path: '/tenants',
    label: 'Tenants',
    icon: 'People',
    requiredPermission: PermissionCode.TENANT_READ,
    group: 'main',
    showInNav: true,
  },
  {
    pageKey: 'dashboard',
    path: '/dashboard',
    label: 'Dashboard',
    icon: 'DataTrending',
    requiredPermission: PermissionCode.ADMIN_MODULE_SCOPED,
    group: 'main',
    showInNav: true,
  },
  {
    pageKey: 'module-mgmt',
    path: '/modules',
    label: 'Module management',
    icon: 'Settings',
    requiredPermission: PermissionCode.MODULE_READ,
    group: 'main',
    showInNav: true,
  },
  {
    pageKey: 'user-profile',
    path: '/user-profile',
    label: 'User profile enrichment',
    icon: 'Person',
    requiredPermission: PermissionCode.USER_PROFILE_READ,
    group: 'main',
    showInNav: true,
  },
  {
    pageKey: 'roles',
    path: '/roles',
    label: 'Role Management',
    icon: 'ShieldTask',
    requiredPermission: PermissionCode.ROLE_READ,
    group: 'security',
    showInNav: true,
  },
  {
    pageKey: 'security-role-mgmt',
    path: '/security/roles',
    label: 'Security role management',
    icon: 'ShieldTask',
    requiredPermission: PermissionCode.ROLE_MANAGE,
    group: 'security',
    showInNav: true,
  },
  {
    pageKey: 'user-role-assign',
    path: '/security/user-assignments',
    label: 'User role assignment',
    icon: 'PeopleTeam',
    requiredPermission: PermissionCode.USER_ASSIGN_ROLE,
    group: 'security',
    showInNav: true,
  },
  {
    pageKey: 'audit-logs',
    path: '/audit/actions',
    label: 'Audit logs',
    icon: 'DocumentBulletList',
    requiredPermission: PermissionCode.AUDIT_VIEW_ACTIONS,
    group: 'security',
    showInNav: true,
  },
] as const satisfies ReadonlyArray<RouteMapEntry>;

export type RouteKey = (typeof ROUTE_MAP)[number]['pageKey'];
