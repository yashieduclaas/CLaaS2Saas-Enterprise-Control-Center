/**
 * Security Control Centre → Role Management → List Roles
 *
 * Governance checklist:
 *   ✅ usePermissionContext — respects permLoading, shows PageSkeleton
 *   ✅ PermissionCode from contracts (RoutePermissionMap uses it)
 *   ✅ PermissionGuard wraps route
 *   ✅ Loading / empty / error / success states
 *   ✅ Fluent UI Table with WCAG 2.1 AA semantics
 *   ✅ Griffel styles via co-located RolesPage.styles.ts
 *   ✅ Table structure ready for virtualization
 */

import {
  Table,
  TableHeader,
  TableHeaderCell,
  TableBody,
  TableRow,
  TableCell,
  Badge,
  Button,
  Skeleton,
  SkeletonItem,
  MessageBar,
  MessageBarBody,
  MessageBarTitle,
  Text,
} from '@fluentui/react-components';
import {
  ShieldTaskRegular,
  ArrowClockwiseRegular,
} from '@fluentui/react-icons';

import { usePermissionContext } from '@/rbac';
import { useRolesQuery } from '../api/useRolesQuery';
import { useRolesPageStyles } from './RolesPage.styles';

const COLUMNS = [
  { columnId: 'name', label: 'Role Name', width: '30%' },
  { columnId: 'description', label: 'Description', width: '40%' },
  { columnId: 'isSystemRole', label: 'Is System Role', width: '15%' },
  { columnId: 'updatedAt', label: 'Updated At', width: '15%' },
] as const;

function formatDate(isoDate: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(isoDate));
  } catch {
    return isoDate;
  }
}

function PageLoadingSkeleton({ styles }: { styles: ReturnType<typeof useRolesPageStyles> }): JSX.Element {
  return (
    <Skeleton aria-label="Loading roles page…">
      <SkeletonItem size={32} className={styles.skeletonTitle} />
      <SkeletonItem size={16} className={styles.skeletonSubtitle} />
      <SkeletonItem size={48} className={styles.skeletonTable} />
      {Array.from({ length: 5 }).map((_, i) => (
        <SkeletonItem key={i} size={40} className={styles.skeletonRowItem} />
      ))}
    </Skeleton>
  );
}

function TableLoadingSkeleton({ styles }: { styles: ReturnType<typeof useRolesPageStyles> }): JSX.Element {
  return (
    <div aria-label="Loading roles…" aria-busy="true" role="status">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className={styles.skeletonRow}>
          <Skeleton className={styles.skeletonInner}>
            <SkeletonItem size={16} />
          </Skeleton>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ styles }: { styles: ReturnType<typeof useRolesPageStyles> }): JSX.Element {
  return (
    <div className={styles.emptyState} role="status" aria-label="No roles found">
      <ShieldTaskRegular className={styles.emptyStateIcon} aria-hidden="true" />
      <p className={styles.emptyStateTitle}>No roles defined</p>
      <p className={styles.emptyStateBody}>
        This tenant has no roles configured yet.
      </p>
    </div>
  );
}

function ErrorState({
  message,
  onRetry,
  styles,
}: {
  message: string;
  onRetry: () => void;
  styles: ReturnType<typeof useRolesPageStyles>;
}): JSX.Element {
  return (
    <div className={styles.errorState} role="alert">
      <MessageBar intent="error" layout="multiline">
        <MessageBarBody>
          <MessageBarTitle>Failed to load roles</MessageBarTitle>
          <p>{message}</p>
        </MessageBarBody>
      </MessageBar>
      <Button
        appearance="secondary"
        icon={<ArrowClockwiseRegular aria-hidden="true" />}
        onClick={onRetry}
        aria-label="Retry loading roles"
      >
        Retry
      </Button>
    </div>
  );
}

export default function RolesPage(): JSX.Element {
  const styles = useRolesPageStyles();
  const { isLoading: permLoading } = usePermissionContext();

  const { data: roles, isLoading, isError, error, refetch } = useRolesQuery();

  if (permLoading) {
    return <PageLoadingSkeleton styles={styles} />;
  }

  return (
    <div className={styles.root}>
      <header className={styles.header}>
        <h1 className={styles.pageTitle}>Role Management</h1>
        <p className={styles.pageSubtitle}>
          View all roles defined in this tenant.
        </p>
      </header>

      <div className={styles.tableContainer}>
        {isLoading ? (
          <TableLoadingSkeleton styles={styles} />
        ) : isError ? (
          <ErrorState
            message={error?.message ?? 'An unexpected error occurred.'}
            onRetry={() => void refetch()}
            styles={styles}
          />
        ) : !roles || roles.length === 0 ? (
          <EmptyState styles={styles} />
        ) : (
          <>
            {/* NOTE: Table designed for future virtualization via DataGrid/Virtualizer. Do not introduce client-side sorting/pagination here. */}
            <Table
            aria-label="Roles table"
            aria-colcount={COLUMNS.length}
            aria-rowcount={roles.length + 1}
            sortable
          >
            <TableHeader>
              <TableRow aria-rowindex={1}>
                {COLUMNS.map((col) => (
                  <TableHeaderCell
                    key={col.columnId}
                    style={{ width: col.width }}
                  >
                    {col.label}
                  </TableHeaderCell>
                ))}
              </TableRow>
            </TableHeader>

            <TableBody>
              {roles.map((role, rowIdx) => (
                <TableRow
                  key={role.id}
                  aria-rowindex={rowIdx + 2}
                >
                  <TableCell>
                    <Text weight="semibold">{role.name}</Text>
                  </TableCell>

                  <TableCell>
                    <Text>
                      {role.description ?? (
                        <Text className={styles.descriptionPlaceholder}>
                          No description
                        </Text>
                      )}
                    </Text>
                  </TableCell>

                  <TableCell>
                    {role.isSystemRole ? (
                      <Badge
                        className={styles.systemRoleBadge}
                        color="informative"
                        shape="rounded"
                        aria-label="System role"
                      >
                        System
                      </Badge>
                    ) : (
                      <Badge
                        className={styles.systemRoleBadge}
                        color="subtle"
                        shape="rounded"
                        aria-label="Custom role"
                      >
                        Custom
                      </Badge>
                    )}
                  </TableCell>

                  <TableCell>
                    <Text
                      className={styles.dateCell}
                      aria-label={`Last updated: ${role.updatedAt}`}
                    >
                      {formatDate(role.updatedAt)}
                    </Text>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </>
        )}
      </div>
    </div>
  );
}
