/**
 * Role Management page — uses useRolesQuery only.
 * Loading, empty, error states. No inline mock.
 */

import { useState } from 'react';
import {
  Table,
  TableHeader,
  TableHeaderCell,
  TableBody,
  TableRow,
  TableCell,
  Badge,
  Button,
  Skeleton,
  SkeletonItem,
  MessageBar,
  MessageBarBody,
  Text,
  Input,
} from '@fluentui/react-components';
import { ShieldTaskRegular, SearchRegular } from '@fluentui/react-icons';
import { makeStyles, tokens } from '@fluentui/react-components';
import { PageSkeleton } from '@/app/PageSkeleton';
import { PermissionCode } from '@claas2saas/contracts';
import { usePermissionContext } from '@/rbac/PermissionProvider';
import { usePermission } from '@/rbac/usePermission';
import { useRolesQuery } from '../api/useRolesQuery';

const COLUMNS = [
  { columnId: 'name', label: 'Role Name', width: '30%' },
  { columnId: 'description', label: 'Description', width: '40%' },
  { columnId: 'isSystemRole', label: 'Is System Role', width: '15%' },
  { columnId: 'updatedAt', label: 'Updated At', width: '15%' },
] as const;

const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalL,
  },
  header: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalXS,
  },
  pageTitle: {
    fontSize: tokens.fontSizeBase600,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
    margin: 0,
  },
  pageSubtitle: {
    fontSize: tokens.fontSizeBase300,
    color: tokens.colorNeutralForeground2,
    margin: 0,
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    gap: tokens.spacingHorizontalM,
    paddingBottom: tokens.spacingVerticalM,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
  },
  searchInput: {
    minWidth: '280px',
  },
  tableContainer: {
    backgroundColor: tokens.colorNeutralBackground1,
    borderRadius: tokens.borderRadiusMedium,
    border: `1px solid ${tokens.colorNeutralStroke2}`,
    overflow: 'hidden',
  },
  emptyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: tokens.spacingVerticalM,
    padding: tokens.spacingVerticalXXL,
    color: tokens.colorNeutralForeground3,
    textAlign: 'center',
  },
  emptyStateIcon: {
    fontSize: tokens.fontSizeBase600,
    color: tokens.colorNeutralForeground4,
  },
  emptyStateTitle: {
    fontSize: tokens.fontSizeBase400,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground2,
    margin: 0,
  },
  emptyStateBody: {
    fontSize: tokens.fontSizeBase300,
    color: tokens.colorNeutralForeground3,
    margin: 0,
  },
  errorState: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalM,
    padding: tokens.spacingVerticalL,
  },
  skeletonRow: {
    display: 'flex',
    gap: tokens.spacingHorizontalM,
    padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalL}`,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
  },
  skeletonTitle: { marginBottom: tokens.spacingVerticalS },
  skeletonSubtitle: { width: '40%', marginBottom: tokens.spacingVerticalL },
  skeletonTable: { marginBottom: tokens.spacingVerticalXS },
  systemRoleBadge: { fontWeight: tokens.fontWeightSemibold, fontSize: tokens.fontSizeBase200 },
  dateCell: { fontSize: tokens.fontSizeBase200, color: tokens.colorNeutralForeground3 },
  descriptionPlaceholder: { fontStyle: 'italic' },
});

function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

function TableSkeleton({ styles }: { styles: ReturnType<typeof useStyles> }): JSX.Element {
  return (
    <div className={styles.tableContainer} aria-label="Loading roles…" aria-busy="true" role="status">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className={styles.skeletonRow}>
          <Skeleton>
            <SkeletonItem size={16} />
          </Skeleton>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ styles, hasActiveSearch }: { styles: ReturnType<typeof useStyles>; hasActiveSearch: boolean }): JSX.Element {
  return (
    <div className={styles.tableContainer}>
      <div className={styles.emptyState} role="status" aria-label="No roles found">
        <ShieldTaskRegular className={styles.emptyStateIcon} aria-hidden />
        <p className={styles.emptyStateTitle}>
          {hasActiveSearch ? 'No matching roles' : 'No roles defined'}
        </p>
        <p className={styles.emptyStateBody}>
          {hasActiveSearch
            ? 'Try a different search term.'
            : 'This tenant has no roles configured yet.'}
        </p>
      </div>
    </div>
  );
}

export default function RoleManagementPage(): JSX.Element {
  const styles = useStyles();
  const { isLoading: permLoading } = usePermissionContext();
  const canCreate = usePermission(PermissionCode.ROLE_MANAGE);

  const [search, setSearch] = useState('');
  const [deferredSearch, setDeferredSearch] = useState('');

  const { data: roles, isLoading, isError, refetch } = useRolesQuery(
    deferredSearch ? { search: deferredSearch, pageSize: 25 } : { pageSize: 25 }
  );

  function handleSearchChange(value: string) {
    setSearch(value);
    const trimmed = value.trim();
    if (trimmed.length === 0 || trimmed.length >= 2) {
      setDeferredSearch(trimmed);
    }
  }

  if (permLoading) return <PageSkeleton />;

  return (
    <div className={styles.root}>
      <header className={styles.header}>
        <h1 className={styles.pageTitle}>Role Management</h1>
        <p className={styles.pageSubtitle}>
          Define and manage security roles for this tenant.
        </p>
      </header>

      <div className={styles.toolbar}>
        <Input
          className={styles.searchInput}
          contentBefore={<SearchRegular aria-hidden="true" />}
          placeholder="Search roles by name or description..."
          value={search}
          onChange={(_, d) => handleSearchChange(d.value)}
          aria-label="Search roles"
          disabled={isLoading}
        />
        {canCreate && (
          <Button appearance="primary">Add Role</Button>
        )}
      </div>

      {isError && (
        <MessageBar intent="error" role="alert">
          <MessageBarBody>
            Failed to load roles.{' '}
            <Button appearance="transparent" size="small" onClick={() => void refetch()}>
              Retry
            </Button>
          </MessageBarBody>
        </MessageBar>
      )}

      <div aria-live="polite" aria-atomic="true" style={{ position: 'absolute', left: '-9999px' }}>
        {isLoading ? 'Loading roles…' : ''}
      </div>

      {isLoading ? (
        <TableSkeleton styles={styles} />
      ) : !roles || roles.length === 0 ? (
        <EmptyState styles={styles} hasActiveSearch={deferredSearch.length > 0} />
      ) : (
        <div className={styles.tableContainer}>
          <Table
            aria-label="Roles table"
            aria-colcount={COLUMNS.length}
            aria-rowcount={roles.length + 1}
            sortable
          >
            <TableHeader>
              <TableRow aria-rowindex={1}>
                {COLUMNS.map((col) => (
                  <TableHeaderCell key={col.columnId} style={{ width: col.width }}>
                    {col.label}
                  </TableHeaderCell>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {roles.map((role, rowIdx) => (
                <TableRow key={role.id} aria-rowindex={rowIdx + 2}>
                  <TableCell>
                    <Text weight="semibold">{role.name}</Text>
                  </TableCell>
                  <TableCell>
                    <Text>
                      {role.description ?? (
                        <Text className={styles.descriptionPlaceholder}>No description</Text>
                      )}
                    </Text>
                  </TableCell>
                  <TableCell>
                    {role.isSystemRole ? (
                      <Badge color="informative" shape="rounded" aria-label="System role">
                        System
                      </Badge>
                    ) : (
                      <Badge color="subtle" shape="rounded" aria-label="Custom role">
                        Custom
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <Text
                      className={styles.dateCell}
                      aria-label={`Last updated: ${role.updatedAt}`}
                    >
                      {formatDate(role.updatedAt)}
                    </Text>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
