/**
 * Roles API module — single entry point for role data.
 * Components MUST NOT fetch directly. Swap to real API client later.
 */

import type { RoleDto } from '@claas2saas/contracts';
import { apiFetch } from '@/api/apiClient';
import { DEMO_ROLES, DEMO_LOAD_DELAY_MS, isDemoDataMode } from '@/demo';

export interface RolesListParams {
  readonly search?: string;
  readonly pageSize?: number;
}

/** Response shape — matches ApiEnvelope<RoleDto[]>. */
export interface RolesListResponse {
  readonly data: readonly RoleDto[];
}

/** Simulated delay for demo mode. */
function delay(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Lists roles for the current tenant.
 * In demo/Local mode: returns static data with simulated delay.
 * Otherwise: GET /api/v1/roles.
 */
export async function listRoles(
  _params?: RolesListParams,
  options?: { token?: string; signal?: AbortSignal },
): Promise<readonly RoleDto[]> {
  if (isDemoDataMode()) {
    await delay(DEMO_LOAD_DELAY_MS);
    const search = _params?.search?.toLowerCase().trim();
    if (search) {
      return DEMO_ROLES.filter(
        (r) =>
          r.name.toLowerCase().includes(search) ||
          (r.description ?? '').toLowerCase().includes(search),
      );
    }
    return DEMO_ROLES;
  }

  const token = options?.token ?? '';
  const data = await apiFetch<readonly RoleDto[]>('/api/v1/roles', token, options?.signal);
  return data ?? [];
}
