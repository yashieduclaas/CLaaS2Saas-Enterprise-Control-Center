/**
 * useRolesQuery — data access layer for roles.
 * Shape matches future React Query usage. Uses rolesApi only.
 */

import { useQuery, type UseQueryResult } from '@tanstack/react-query';
import type { RoleDto } from '@claas2saas/contracts';
import { useAuth } from '@/auth/useAuth';
import { listRoles } from './rolesApi';

export interface UseRolesQueryParams {
  readonly search?: string;
  readonly pageSize?: number;
}

export const ROLES_QUERY_KEY = {
  all: (tenantId: string) => ['roles', tenantId] as const,
  list: (tenantId: string, query?: UseRolesQueryParams) =>
    ['roles', tenantId, 'list', query ?? {}] as const,
} as const;

/**
 * Fetches roles via rolesApi. No direct fetch in components.
 * Demo mode: uses mock adapter with simulated delay.
 */
export function useRolesQuery(
  params?: UseRolesQueryParams,
): UseQueryResult<readonly RoleDto[], Error> {
  const { getAccessToken, isAuthenticated, tenantId } = useAuth();
  const cacheTenant = tenantId || 'demo';

  return useQuery({
    queryKey: ROLES_QUERY_KEY.list(cacheTenant, params),
    enabled: isAuthenticated,
    retry: 1,
    queryFn: async ({ signal }) => {
      const token = await getAccessToken();
      return listRoles(params, { token, signal });
    },
  });
}
