/**
 * React Query hook for GET /api/v1/audit/actions
 */

import { useQuery, type UseQueryResult } from '@tanstack/react-query';
import { useAuth } from '@/auth/useAuth';
import { apiFetch } from '@/api/apiClient';

export interface AuditActionLogDto {
  readonly id: string;
  readonly tenantId: string;
  readonly userId: string;
  readonly action: string;
  readonly resource: string;
  readonly result: string;
  readonly permissionsVersion?: string;
  readonly timestamp: string;
}

export const AUDIT_ACTIONS_QUERY_KEY = {
  all: (tenantId: string) => ['audit', 'actions', tenantId] as const,
  list: (tenantId: string, page: number, pageSize: number) =>
    ['audit', 'actions', tenantId, page, pageSize] as const,
} as const;

export function useAuditActionsQuery(
  page = 1,
  pageSize = 20,
): UseQueryResult<readonly AuditActionLogDto[], Error> {
  const { getAccessToken, isAuthenticated, tenantId } = useAuth();

  return useQuery({
    queryKey: AUDIT_ACTIONS_QUERY_KEY.list(tenantId, page, pageSize),
    enabled: isAuthenticated,
    retry: 1,
    queryFn: async ({ signal }) => {
      const token = await getAccessToken();
      const path = `/api/v1/audit/actions?page=${page}&pageSize=${pageSize}`;
      return apiFetch<readonly AuditActionLogDto[]>(path, token, signal);
    },
  });
}
