/**
 * Audit Actions page — full vertical slice.
 * Uses GET /api/audit/actions, Fluent Table, skeleton/empty/error states.
 */

import {
  Table,
  TableHeader,
  TableHeaderCell,
  TableBody,
  TableRow,
  TableCell,
  makeStyles,
  tokens,
  MessageBar,
  MessageBarBody,
  Skeleton,
  SkeletonItem,
  Text,
} from '@fluentui/react-components';
import { useAuditActionsQuery, type AuditActionLogDto } from '../api/useAuditActionsQuery';
import { useAuth } from '@/auth/useAuth';

const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalL,
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: tokens.spacingVerticalM,
  },
  pageTitle: {
    fontSize: tokens.fontSizeBase500,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
  },
  tenantBadge: {
    fontSize: tokens.fontSizeBase300,
    color: tokens.colorNeutralForeground2,
  },
  table: {
    overflow: 'auto',
  },
});

function formatTimestamp(iso: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export function AuditActionsPage(): JSX.Element {
  const styles = useStyles();
  const { tenantId } = useAuth();
  const { data, isLoading, isError, error } = useAuditActionsQuery(1, 20);

  if (isLoading) {
    return (
      <div className={styles.root}>
        <Skeleton aria-label="Loading audit logs">
          <SkeletonItem size={32} />
          <SkeletonItem size={16} />
          <SkeletonItem size={200} />
        </Skeleton>
      </div>
    );
  }

  if (isError) {
    return (
      <div className={styles.root}>
        <MessageBar intent="error">
          <MessageBarBody>{error?.message ?? 'Failed to load audit logs.'}</MessageBarBody>
        </MessageBar>
      </div>
    );
  }

  const items = data ?? [];

  return (
    <div className={styles.root}>
      <header className={styles.header}>
        <h1 className={styles.pageTitle}>Audit Logs</h1>
        <Text className={styles.tenantBadge}>Tenant: {tenantId || '—'}</Text>
      </header>

      {items.length === 0 ? (
        <MessageBar intent="info">
          <MessageBarBody>No audit log entries found.</MessageBarBody>
        </MessageBar>
      ) : (
        <div className={styles.table}>
          <Table
            aria-label="Audit action logs"
            aria-colcount={6}
            aria-rowcount={items.length + 1}
          >
            <TableHeader>
              <TableRow>
                <TableHeaderCell>Timestamp</TableHeaderCell>
                <TableHeaderCell>User</TableHeaderCell>
                <TableHeaderCell>Action</TableHeaderCell>
                <TableHeaderCell>Resource</TableHeaderCell>
                <TableHeaderCell>Result</TableHeaderCell>
                <TableHeaderCell>Permissions Version</TableHeaderCell>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{formatTimestamp(row.timestamp)}</TableCell>
                  <TableCell>{row.userId}</TableCell>
                  <TableCell>{row.action}</TableCell>
                  <TableCell>{row.resource}</TableCell>
                  <TableCell>{row.result}</TableCell>
                  <TableCell>{row.permissionsVersion ?? '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
