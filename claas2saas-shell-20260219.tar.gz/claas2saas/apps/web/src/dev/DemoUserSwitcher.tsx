/**
 * Demo user switcher — DEV ONLY. Renders when VITE_AUTH_MODE=demo.
 * On select: updates localStorage, dispatches demo-user-changed, triggers PermissionProvider.refresh.
 */

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dropdown, Option, makeStyles } from '@fluentui/react-components';
import { setDemoUser, getDemoUserEmail, DEMO_USERS } from '../auth/DemoAuthProvider';
import { usePermissionContext } from '@/rbac';

const useStyles = makeStyles({
  root: {
    minWidth: '200px',
  },
});

export function DemoUserSwitcher(): JSX.Element {
  const styles = useStyles();
  const navigate = useNavigate();
  const { refresh } = usePermissionContext();
  const [current, setCurrent] = useState(getDemoUserEmail);

  useEffect(() => {
    const onChanged = () => setCurrent(getDemoUserEmail());
    window.addEventListener('demo-user-changed', onChanged);
    return () => window.removeEventListener('demo-user-changed', onChanged);
  }, []);

  const onSelect = (_: unknown, data: { optionValue?: string }) => {
    const email = data.optionValue;
    if (!email) return;
    setDemoUser(email);
    setCurrent(email);
    refresh();
    navigate('/');
  };

  const selectedOption = DEMO_USERS.find((u) => u.email === current);

  return (
    <div className={styles.root}>
      <Dropdown
        value={selectedOption?.label ?? current}
        onOptionSelect={onSelect}
        placeholder="Select demo user"
        aria-label="Demo user switcher"
      >
        {DEMO_USERS.map((u) => (
          <Option key={u.email} value={u.email} text={u.label}>
            {u.label}
          </Option>
        ))}
      </Dropdown>
    </div>
  );
}
