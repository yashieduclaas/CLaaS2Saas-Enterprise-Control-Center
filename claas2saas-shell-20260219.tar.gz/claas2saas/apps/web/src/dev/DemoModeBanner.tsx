/**
 * Fixed warning strip + user switcher for demo mode. Renders when VITE_AUTH_MODE=demo.
 */

import { makeStyles, tokens } from '@fluentui/react-components';
import { DemoUserSwitcher } from './DemoUserSwitcher';

const useStyles = makeStyles({
  banner: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 9999,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: tokens.spacingHorizontalM,
    backgroundColor: tokens.colorPaletteYellowBackground2,
    color: tokens.colorPaletteYellowForeground1,
    padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalM}`,
    fontSize: tokens.fontSizeBase200,
    fontWeight: tokens.fontWeightSemibold,
    borderBottom: `1px solid ${tokens.colorPaletteYellowBorder1}`,
  },
  text: {
    flex: 1,
  },
});

export function DemoModeBanner(): JSX.Element {
  const styles = useStyles();
  return (
    <div className={styles.banner} role="alert">
      <span className={styles.text}>⚠ DEMO MODE — No external services connected.</span>
      <DemoUserSwitcher />
    </div>
  );
}
