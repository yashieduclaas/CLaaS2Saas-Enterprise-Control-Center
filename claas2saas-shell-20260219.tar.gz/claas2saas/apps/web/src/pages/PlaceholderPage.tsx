/**
 * Placeholder for routes not yet implemented.
 */

import { makeStyles, tokens, Text } from '@fluentui/react-components';

const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalL,
  },
  title: {
    fontSize: tokens.fontSizeBase600,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
  },
});

interface PlaceholderPageProps {
  title: string;
}

export function PlaceholderPage({ title }: PlaceholderPageProps): JSX.Element {
  const styles = useStyles();
  return (
    <div className={styles.root}>
      <h1 className={styles.title}>{title}</h1>
      <Text>This page is a placeholder. Backend wiring coming soon.</Text>
    </div>
  );
}
