import { Title1, Text } from '@fluentui/react-components';
import { PermissionCode } from '@claas2saas/contracts';
import { usePermissionContext, usePermission } from '@/rbac';

export function TenantsPage(): JSX.Element {
  const { isLoading } = usePermissionContext();
  const canRead = usePermission(PermissionCode.TENANT_READ);

  if (isLoading) return <Text>Loading permissions…</Text>;
  if (!canRead) return <Text>Access denied.</Text>;

  return (
    <>
      <Title1>Tenants</Title1>
      <Text>Tenant management feature pod will render here.</Text>
    </>
  );
}
