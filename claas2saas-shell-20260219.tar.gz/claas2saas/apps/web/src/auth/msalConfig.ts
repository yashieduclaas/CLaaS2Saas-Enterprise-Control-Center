import { Configuration, LogLevel, BrowserCacheLocation } from '@azure/msal-browser';

/**
 * PLATFORM AUTH CONFIG — FROZEN.
 *
 * MSAL PKCE configuration for Entra ID.
 * Required env vars:
 *   VITE_ENTRA_CLIENT_ID
 *   VITE_ENTRA_TENANT_ID
 *   VITE_ENTRA_REDIRECT_URI (optional, defaults to window.location.origin)
 */
export const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env['VITE_ENTRA_CLIENT_ID'] as string,
    authority: `https://login.microsoftonline.com/${import.meta.env['VITE_ENTRA_TENANT_ID'] as string}`,
    redirectUri: (import.meta.env['VITE_ENTRA_REDIRECT_URI'] as string | undefined) ?? window.location.origin,
    postLogoutRedirectUri: window.location.origin,
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: BrowserCacheLocation.SessionStorage,
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) return;
        switch (level) {
          case LogLevel.Error:   console.error('[MSAL]', message); break;
          case LogLevel.Warning: console.warn('[MSAL]', message);  break;
          case LogLevel.Info:    console.info('[MSAL]', message);   break;
          default:               console.debug('[MSAL]', message);  break;
        }
      },
      piiLoggingEnabled: false,
      logLevel: import.meta.env.DEV ? LogLevel.Info : LogLevel.Warning,
    },
  },
};

export const defaultScopes: string[] = [
  `api://${import.meta.env['VITE_ENTRA_CLIENT_ID'] as string}/user_impersonation`,
];
