/**
 * Demo auth provider for AUTH_MODE=demo.
 * Reads current user from localStorage['demo-user'], synthesizes auth state.
 * No Entra, no MSAL. X-Demo-User header is set by api layer for all requests.
 */

import { useEffect, type ReactNode } from 'react';
import { AuthContextProvider, useAuthContext } from './AuthContext';

const DEMO_USER_KEY = 'demo-user';
const DEFAULT_DEMO_USER = 'global.admin@demo.com';

const DEMO_USERS = [
  { email: 'global.admin@demo.com', label: 'Global Admin', tenantId: 'tenant-global' },
  { email: 'security.admin@demo.com', label: 'Security Admin', tenantId: 'tenant-a' },
  { email: 'helpdesk@demo.com', label: 'Help Desk', tenantId: 'tenant-a' },
  { email: 'user@tenantA.com', label: 'User TenantA', tenantId: 'tenant-a' },
  { email: 'user@tenantB.com', label: 'User TenantB', tenantId: 'tenant-b' },
] as const;

function getDemoUser(): string {
  if (typeof window === 'undefined') return DEFAULT_DEMO_USER;
  return localStorage.getItem(DEMO_USER_KEY) || DEFAULT_DEMO_USER;
}

function DemoAuthInner({ children }: { readonly children: ReactNode }): JSX.Element {
  const user = getDemoUser();
  const info = DEMO_USERS.find((u) => u.email === user) ?? DEMO_USERS[0];

  const value = {
    account: {
      localAccountId: `demo-${info.email}`,
      username: info.email,
      tenantId: info.tenantId,
    },
    isLoading: false,
    acquireToken: async () => 'demo',
    signIn: async () => {},
    signOut: async () => {},
  };

  return <AuthContextProvider value={value}>{children}</AuthContextProvider>;
}

export function DemoAuthProvider({ children }: { readonly children: ReactNode }): JSX.Element {
  return <DemoAuthInner>{children}</DemoAuthInner>;
}

/** For DemoUserSwitcher: update stored user and trigger refresh. */
export function setDemoUser(email: string): void {
  localStorage.setItem(DEMO_USER_KEY, email);
  window.dispatchEvent(new Event('demo-user-changed'));
}

export function getDemoUserEmail(): string {
  return getDemoUser();
}

export { DEMO_USERS, DEMO_USER_KEY, DEFAULT_DEMO_USER };
