/**
 * Wrapper that loads MSAL/AuthProvider + AuthBridge only when AUTH_MODE=Entra.
 * This file is NEVER imported when VITE_AUTH_MODE=demo, preventing MSAL
 * from initializing with missing VITE_ENTRA_* env vars and crashing the app.
 */

import type { ReactNode } from 'react';
import { AuthProvider } from './AuthProvider';
import { AuthBridge } from './AuthBridge';

export function EntraAuthShell({ children }: { readonly children: ReactNode }): JSX.Element {
  return (
    <AuthProvider>
      <AuthBridge>{children}</AuthBridge>
    </AuthProvider>
  );
}
