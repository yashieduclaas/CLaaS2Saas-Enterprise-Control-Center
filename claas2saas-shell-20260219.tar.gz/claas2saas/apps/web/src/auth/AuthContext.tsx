/**
 * Shared auth context for both MSAL (Entra) and Demo mode.
 * AuthBridge (inside AuthProvider) and DemoAuthProvider both provide this context.
 */

import { createContext, useContext, type ReactNode } from 'react';

export interface AuthContextValue {
  readonly account: { localAccountId: string; username?: string; tenantId?: string } | null;
  readonly isLoading: boolean;
  acquireToken: () => Promise<string>;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function useAuthContext(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuthContext must be used within AuthProvider or DemoAuthProvider.');
  return ctx;
}

export interface AuthContextProviderProps {
  readonly value: AuthContextValue;
  readonly children: ReactNode;
}

export function AuthContextProvider({ value, children }: AuthContextProviderProps): JSX.Element {
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
