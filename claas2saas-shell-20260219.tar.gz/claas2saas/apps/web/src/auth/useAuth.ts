/**
 * Auth hook adapter for feature pods.
 * Works with both AuthProvider (Entra) and DemoAuthProvider via AuthContext.
 * Exposes getAccessToken, isAuthenticated, tenantId, account.
 */

import { useAuthContext } from './AuthContext';

export function useAuth(): {
  getAccessToken: () => Promise<string>;
  isAuthenticated: boolean;
  /** Tenant identifier for cache scoping. Empty when unauthenticated. */
  tenantId: string;
  /** Account info (username, etc.). Null when unauthenticated. */
  account: { username?: string; tenantId?: string } | null;
} {
  const { acquireToken, account } = useAuthContext();
  return {
    getAccessToken: acquireToken,
    isAuthenticated: Boolean(account),
    tenantId: account?.tenantId ?? '',
    account,
  };
}
