/**
 * Bridges MSAL (AuthProvider) to AuthContext.
 * Renders inside AuthProvider so useMsal is available.
 * Provides AuthContext for downstream PermissionProvider and useAuth consumers.
 */

import { type ReactNode } from 'react';
import { useMsal, InteractionStatus } from '@azure/msal-react';
import { defaultScopes } from './msalConfig';
import { AuthContextProvider } from './AuthContext';

export function AuthBridge({ children }: { readonly children: ReactNode }): JSX.Element {
  const { instance, accounts, inProgress } = useMsal();
  const account = accounts[0] ?? null;
  const isLoading = inProgress !== InteractionStatus.None;

  const acquireToken = async (): Promise<string> => {
    if (!account) throw new Error('No authenticated account.');
    try {
      const result = await instance.acquireTokenSilent({ account, scopes: defaultScopes });
      return result.accessToken;
    } catch {
      await instance.acquireTokenRedirect({ account, scopes: defaultScopes });
      throw new Error('Redirect initiated.');
    }
  };

  const value = {
    account: account
      ? {
          localAccountId: account.localAccountId,
          username: account.username,
          tenantId: account.tenantId,
        }
      : null,
    isLoading,
    acquireToken,
    signIn: async () => instance.loginRedirect({ scopes: defaultScopes }),
    signOut: async () => instance.logoutRedirect({ account: account ?? undefined }),
  };

  return <AuthContextProvider value={value}>{children}</AuthContextProvider>;
}
