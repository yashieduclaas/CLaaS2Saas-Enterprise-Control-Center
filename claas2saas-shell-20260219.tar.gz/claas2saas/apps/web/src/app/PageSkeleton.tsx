/**
 * Page-level loading skeleton. Fluent tokens only.
 */

import { makeStyles, tokens, Skeleton, SkeletonItem } from '@fluentui/react-components';

const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacingVerticalM,
  },
});

export function PageSkeleton(): JSX.Element {
  const styles = useStyles();
  return (
    <Skeleton aria-label="Loading page…" className={styles.root}>
      <SkeletonItem size={32} />
      <SkeletonItem size={16} />
      <SkeletonItem size={48} />
    </Skeleton>
  );
}
