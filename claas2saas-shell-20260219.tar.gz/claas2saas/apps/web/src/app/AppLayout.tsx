/**
 * App shell — NavRail + TopBar + main content.
 * Entra-style layout. Feature content in main only.
 */

import { useState, type ReactNode } from 'react';
import { makeStyles, tokens } from '@fluentui/react-components';
import { NavRail } from './NavRail';
import { TopBar } from './TopBar';

const useStyles = makeStyles({
  shell: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    overflow: 'hidden',
    backgroundColor: tokens.colorNeutralBackground2,
  },
  body: {
    display: 'flex',
    flex: 1,
    overflow: 'hidden',
  },
  main: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'auto',
    padding: tokens.spacingHorizontalXL,
  },
});

interface AppLayoutProps {
  readonly children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps): JSX.Element {
  const styles = useStyles();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className={styles.shell}>
      <TopBar />
      <div className={styles.body}>
        <NavRail collapsed={collapsed} onToggleCollapse={() => setCollapsed((c) => !c)} />
        <main className={styles.main} id="main-content" tabIndex={-1}>
          {children}
        </main>
      </div>
    </div>
  );
}
