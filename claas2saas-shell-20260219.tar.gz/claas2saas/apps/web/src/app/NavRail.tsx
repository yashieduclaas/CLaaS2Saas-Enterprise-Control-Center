/**
 * Entra-style collapsible NavRail.
 * Generated from ROUTE_MAP only — NO hardcoded nav JSX.
 */

import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { makeStyles, tokens, mergeClasses, Tooltip } from '@fluentui/react-components';
import {
  HomeRegular,
  ShieldTaskRegular,
  PeopleTeamRegular,
  PersonRegular,
  DocumentBulletListRegular,
  SettingsRegular,
  PeopleRegular,
  DataTrendingRegular,
} from '@fluentui/react-icons';
import { ROUTE_MAP, type RouteMapEntry } from '@/routes/RoutePermissionMap';
import { usePermission } from '@/rbac/usePermission';
import type { PermissionCodeType } from '@claas2saas/contracts';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Home: HomeRegular,
  People: PeopleRegular,
  DataTrending: DataTrendingRegular,
  Settings: SettingsRegular,
  Person: PersonRegular,
  ShieldTask: ShieldTaskRegular,
  PeopleTeam: PeopleTeamRegular,
  DocumentBulletList: DocumentBulletListRegular,
};

const GROUP_LABELS: Record<string, string> = {
  main: 'Main',
  security: 'Security Control Centre',
};

const useStyles = makeStyles({
  rail: {
    display: 'flex',
    flexDirection: 'column',
    width: '220px',
    minWidth: '220px',
    backgroundColor: tokens.colorNeutralBackground1,
    borderRight: `1px solid ${tokens.colorNeutralStroke2}`,
    transition: 'width 200ms ease, min-width 200ms ease',
    overflow: 'hidden',
  },
  railCollapsed: {
    width: '48px',
    minWidth: '48px',
  },
  railHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalM}`,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    minHeight: '48px',
  },
  wordmark: {
    fontSize: tokens.fontSizeBase300,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
  },
  toggleBtn: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: tokens.colorNeutralForeground2,
    borderRadius: tokens.borderRadiusMedium,
    ':hover': {
      backgroundColor: tokens.colorNeutralBackground1Hover,
    },
  },
  sectionLabel: {
    padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalM}`,
    fontSize: tokens.fontSizeBase200,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground3,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  navList: {
    listStyle: 'none',
    margin: 0,
    padding: `${tokens.spacingVerticalS} 0`,
    flex: 1,
    overflowY: 'auto',
  },
  navItem: {
    display: 'flex',
    alignItems: 'center',
    gap: tokens.spacingHorizontalS,
    padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalM}`,
    color: tokens.colorNeutralForeground2,
    textDecoration: 'none',
    borderRadius: tokens.borderRadiusMedium,
    margin: `2px ${tokens.spacingHorizontalXS}`,
    fontSize: tokens.fontSizeBase300,
    ':hover': {
      backgroundColor: tokens.colorNeutralBackground1Hover,
      color: tokens.colorNeutralForeground1,
    },
  },
  navItemActive: {
    backgroundColor: tokens.colorBrandBackground2,
    color: tokens.colorBrandForeground1,
    fontWeight: tokens.fontWeightSemibold,
  },
  navItemCollapsed: {
    justifyContent: 'center',
    padding: tokens.spacingVerticalS,
  },
  icon: {
    flexShrink: 0,
    fontSize: '20px',
  },
  listItem: {
    listStyle: 'none',
    margin: 0,
  },
});

function NavItem({ entry, collapsed }: { entry: RouteMapEntry; collapsed: boolean }): React.ReactElement | null {
  const styles = useStyles();
  const location = useLocation();
  const hasPermission = usePermission(entry.requiredPermission as PermissionCodeType | null);

  if (entry.requiredPermission && !hasPermission) return null;

  const isActive =
    location.pathname === entry.path || location.pathname.startsWith(entry.path + '/');
  const Icon = ICON_MAP[entry.icon] ?? HomeRegular;

  const link = (
    <NavLink
      to={entry.path}
      className={mergeClasses(
        styles.navItem,
        isActive && styles.navItemActive,
        collapsed && styles.navItemCollapsed
      )}
      title={entry.label}
      aria-label={collapsed ? entry.label : undefined}
      aria-current={isActive ? 'page' : undefined}
    >
      <Icon className={styles.icon} aria-hidden />
      {!collapsed && <span>{entry.label}</span>}
    </NavLink>
  );

  return (
    <li className={styles.listItem}>
      {collapsed ? (
        <Tooltip content={entry.label} relationship="label" positioning="after" showDelay={300}>
          {link}
        </Tooltip>
      ) : (
        link
      )}
    </li>
  );
}

interface NavRailProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function NavRail({ collapsed, onToggleCollapse }: NavRailProps): JSX.Element {
  const styles = useStyles();
  const navEntries = ROUTE_MAP.filter((e) => e.showInNav);
  const groups = ['main', 'security'] as const;
  const grouped = groups.map((group) => ({
    group,
    entries: navEntries.filter((e) => e.group === group),
  })).filter((g) => g.entries.length > 0);

  return (
    <nav
      className={mergeClasses(styles.rail, collapsed && styles.railCollapsed)}
      aria-label="Primary navigation"
    >
      <div className={styles.railHeader}>
        {!collapsed && <span className={styles.wordmark}>CLaaS2SaaS</span>}
        <button
          type="button"
          className={styles.toggleBtn}
          onClick={onToggleCollapse}
          aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
        >
          {collapsed ? '›' : '‹'}
        </button>
      </div>

      <ul className={styles.navList} role="list">
        {grouped.map(({ group, entries }) => (
          <React.Fragment key={group}>
            {!collapsed && GROUP_LABELS[group] && (
              <li className={styles.sectionLabel}>
                {GROUP_LABELS[group]}
              </li>
            )}
            {entries.map((entry) => (
              <NavItem key={entry.pageKey} entry={entry} collapsed={collapsed} />
            ))}
          </React.Fragment>
        ))}
      </ul>
    </nav>
  );
}
