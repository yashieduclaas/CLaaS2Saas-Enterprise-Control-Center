/**
 * Top bar — breadcrumb and tenant context.
 * Entra-style. Placeholder for future user menu, search.
 */

import { useLocation } from 'react-router-dom';
import { makeStyles, tokens, Text } from '@fluentui/react-components';
import { ROUTE_MAP } from '@/routes/RoutePermissionMap';

const useStyles = makeStyles({
  root: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: '48px',
    padding: `0 ${tokens.spacingHorizontalXL}`,
    backgroundColor: tokens.colorNeutralBackground1,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
  },
  breadcrumb: {
    fontSize: tokens.fontSizeBase300,
    color: tokens.colorNeutralForeground2,
  },
  title: {
    fontSize: tokens.fontSizeBase400,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
  },
});

export function TopBar(): JSX.Element {
  const styles = useStyles();
  const location = useLocation();

  const activeEntry = ROUTE_MAP.find((e) => e.path === location.pathname);
  const title = activeEntry?.label ?? 'Security Control Centre';

  return (
    <header className={styles.root} role="banner">
      <nav aria-label="Breadcrumb">
        <Text className={styles.breadcrumb}>
          CLaaS2SaaS / <span className={styles.title}>{title}</span>
        </Text>
      </nav>
    </header>
  );
}
