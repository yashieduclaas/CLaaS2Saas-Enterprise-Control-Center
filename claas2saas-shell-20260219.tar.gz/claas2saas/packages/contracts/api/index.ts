/**
 * API envelope contracts.
 */

export interface ApiResponse<T> {
  readonly success: boolean;
  readonly data: T | null;
  readonly errorCode: string | null;
  readonly errorMessage: string | null;
}

/** Success envelope for GET endpoints. */
export interface ApiEnvelope<T> {
  readonly data: T;
}

/** Pagination/sort params for list endpoints. Reserved for future use. */
export interface ListQuery {
  readonly pageNumber?: number;
  readonly pageSize?: number;
  readonly sortBy?: string;
  readonly sortDirection?: 'asc' | 'desc';
}
