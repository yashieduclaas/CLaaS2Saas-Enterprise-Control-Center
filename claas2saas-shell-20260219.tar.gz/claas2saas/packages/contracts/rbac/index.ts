/**
 * RBAC contracts — placeholder.
 * Define role, permission, and assignment shapes here.
 */

export interface PermissionKey {
  readonly domain: string;
  readonly action: string;
}

export type PermissionString = `${string}:${string}`;

/**
 * Permission constants — use these instead of string literals.
 * Format: DOMAIN:ACTION (singular module namespace).
 * MUST match backend Permissions.cs and permission snapshot payload exactly.
 */
export const PermissionCode = {
  /** Read tenants. Aligns with backend Permissions.TenantRead = "TENANT:READ". */
  TENANT_READ: 'TENANT:READ',
  /** Read roles for the current tenant. Aligns with backend Permissions.RoleRead = "ROLE:READ". */
  ROLE_READ: 'ROLE:READ',
  /** View audit action records. */
  AUDIT_VIEW_ACTIONS: 'AUDIT:VIEW_ACTIONS',
  /** Module-scoped admin. */
  ADMIN_MODULE_SCOPED: 'ADMIN:MODULE_SCOPED',
  /** Placeholder: module management. */
  MODULE_READ: 'MODULE:READ',
  /** Placeholder: user profile enrichment. */
  USER_PROFILE_READ: 'USER_PROFILE:READ',
  /** Placeholder: security role management. */
  ROLE_MANAGE: 'ROLE:MANAGE',
  /** Placeholder: user role assignment. */
  USER_ASSIGN_ROLE: 'USER:ASSIGN_ROLE',
} as const;

export type PermissionCodeType = (typeof PermissionCode)[keyof typeof PermissionCode];

export type { RoleDto } from './RoleDto';
