/**
 * Route contracts — placeholder.
 * Aligns with frontend ROUTE_MAP.
 */

export interface RouteDescriptor {
  readonly path: string;
  readonly requiredPermission: string | null;
}
